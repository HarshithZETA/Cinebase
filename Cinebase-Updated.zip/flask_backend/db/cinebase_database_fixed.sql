DROP DATABASE IF EXISTS cinebase;
CREATE DATABASE cinebase;
USE cinebase;

CREATE TABLE IF NOT EXISTS Industry (
    Industry_ID INT AUTO_INCREMENT PRIMARY KEY,
    Industry_Name VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS Genre (
    Genre_ID INT AUTO_INCREMENT PRIMARY KEY,
    Genre_Name VARCHAR(50) NOT NULL UNIQUE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS Person (
    Person_ID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    Date_of_Birth DATE,
    Role_Type ENUM('Actor', 'Director', 'Writer', 'Music Director') NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS Movies (
    Movie_ID INT AUTO_INCREMENT PRIMARY KEY,
    Title_English VARCHAR(255) NOT NULL,
    Release_Year YEAR NOT NULL,
    Duration_Min INT,
    Plot_Summary TEXT,
    IMDB_Rating DECIMAL(2, 1),
    Industry_ID INT,
    FOREIGN KEY (Industry_ID) REFERENCES Industry(Industry_ID)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS Box_Office (
    Box_Office_ID INT AUTO_INCREMENT PRIMARY KEY,
    Movie_ID INT UNIQUE,
    Budget_INR_Cr DECIMAL(10, 2),
    Revenue_INR_Cr DECIMAL(10, 2),
    FOREIGN KEY (Movie_ID) REFERENCES Movies(Movie_ID) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS Movie_Genre (
    Movie_ID INT,
    Genre_ID INT,
    PRIMARY KEY (Movie_ID, Genre_ID),
    FOREIGN KEY (Movie_ID) REFERENCES Movies(Movie_ID) ON DELETE CASCADE,
    FOREIGN KEY (Genre_ID) REFERENCES Genre(Genre_ID) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS Movie_Person_Role (
    Movie_ID INT,
    Person_ID INT,
    Role_Description VARCHAR(100),
    PRIMARY KEY (Movie_ID, Person_ID),
    FOREIGN KEY (Movie_ID) REFERENCES Movies(Movie_ID) ON DELETE CASCADE,
    FOREIGN KEY (Person_ID) REFERENCES Person(Person_ID) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS Award (
    Award_ID INT AUTO_INCREMENT PRIMARY KEY,
    Award_Name VARCHAR(255) NOT NULL,
    Award_Year YEAR NOT NULL,
    Movie_ID INT,
    Person_ID INT,
    FOREIGN KEY (Movie_ID) REFERENCES Movies(Movie_ID),
    FOREIGN KEY (Person_ID) REFERENCES Person(Person_ID)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO Industry (Industry_Name) VALUES
('Bollywood'), ('Kollywood'), ('Tollywood');

INSERT IGNORE INTO Genre (Genre_Name) VALUES
('Action'), ('Drama'), ('Romance'), ('Comedy'), ('Thriller');

INSERT IGNORE INTO Person (Name, Date_of_Birth, Role_Type) VALUES
('Shah Rukh Khan', '1965-11-02', 'Actor'), 
('S.S. Rajamouli', '1973-10-10', 'Director'), 
('Prabhas', '1979-10-23', 'Actor'),
('Deepika Padukone', '1986-01-05', 'Actor'), 
('Atlee', '1986-09-21', 'Director'),
('Anushka Shetty', '1981-11-07', 'Actor');

INSERT INTO Movies (Title_English, Release_Year, Duration_Min, IMDB_Rating, Industry_ID, Plot_Summary) VALUES
('Jawan', 2023, 169, 7.0, 1, 'A soldier is out to correct the wrongs in society.'),
('Baahubali: The Beginning', 2015, 159, 8.0, 3, 'A son fights to reclaim his rightful throne from a cruel uncle.'),
('Pathaan', 2023, 146, 5.9, 1, 'An exiled RAW agent battles a notorious terror outfit.'),
('Bigil', 2019, 179, 7.5, 2, 'A former football player coaches a women''s team to overcome adversity.');

INSERT INTO Box_Office (Movie_ID, Budget_INR_Cr, Revenue_INR_Cr) VALUES
(1, 300.00, 1150.00),
(2, 180.00, 650.00),
(3, 225.00, 1050.00),
(4, 180.00, 300.00);

INSERT INTO Movie_Genre (Movie_ID, Genre_ID) VALUES
(1, 1), (1, 5),
(2, 1), (2, 2),
(3, 1), (3, 5),
(4, 2), (4, 4);

INSERT INTO Movie_Person_Role (Movie_ID, Person_ID, Role_Description) VALUES
(1, 1, 'Lead Actor'), (1, 5, 'Director'),
(2, 3, 'Lead Actor'), (2, 2, 'Director'),
(3, 1, 'Lead Actor'), (3, 4, 'Lead Actress'),
(4, 3, 'Lead Actor'), (4, 5, 'Director');
