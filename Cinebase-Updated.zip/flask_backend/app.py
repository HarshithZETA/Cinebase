# app.py

from flask import Flask, jsonify, request, send_from_directory
from db.connection import get_connection # Imports the pymysql connection function
from flask_cors import CORS
import json
import os
from werkzeug.exceptions import NotFound

# App configuration
app = Flask(__name__, static_folder='public', static_url_path='/')
CORS(app)

# Serve static files (HTML)
@app.route('/')
def index():
    # Serves public/index.html when accessing http://localhost:3000/
    return send_from_directory(app.static_folder, 'index.html')

# --- API ROUTES ---

# GET all movies / Search (READ)
@app.route('/api/movies', methods=['GET'])
def get_movies():
    search_term = request.args.get('q', '')
    
    conn = get_connection()
    cursor = conn.cursor()
    
    # Comprehensive Query: Joins six tables and uses GROUP_CONCAT for genres/cast
    query = """
    SELECT 
        m.Movie_ID AS id,
        m.Title_English AS title,
        m.Release_Year AS year,
        m.Duration_Min AS duration,
        m.IMDB_Rating AS rating,
        m.Plot_Summary AS plot,
        i.Industry_Name AS industry,
        bo.Budget_INR_Cr AS budget,
        bo.Revenue_INR_Cr AS revenue,
        
        GROUP_CONCAT(DISTINCT g.Genre_Name) AS genres,
        (SELECT GROUP_CONCAT(CONCAT(P.Name, ' (', MPR.Role_Description, ')') SEPARATOR ', ')
         FROM Movie_Person_Role MPR JOIN Person P ON MPR.Person_ID = P.Person_ID 
         WHERE MPR.Movie_ID = m.Movie_ID) AS cast_crew,
        (SELECT GROUP_CONCAT(A.Award_Name) FROM Award A WHERE A.Movie_ID = m.Movie_ID) AS awards
         
    FROM Movies m
    JOIN Industry i ON m.Industry_ID = i.Industry_ID
    LEFT JOIN Box_Office bo ON m.Movie_ID = bo.Movie_ID
    LEFT JOIN Movie_Genre mg ON m.Movie_ID = mg.Movie_ID
    LEFT JOIN Genre g ON mg.Genre_ID = g.Genre_ID
    WHERE m.Title_English LIKE %s OR m.Plot_Summary LIKE %s
    GROUP BY m.Movie_ID
    ORDER BY m.Release_Year DESC;
    """
    
    search_param = f"%{search_term}%"
    
    try:
        cursor.execute(query, (search_param, search_param))
        rows = cursor.fetchall()
        return jsonify(rows)
    except Exception as e:
        # 400 Bad Request if the SQL syntax fails (rare) or 500 for general DB error
        return jsonify({'error': str(e)}), 500 
    finally:
        cursor.close()
        conn.close()

# Create movie (CREATE)
@app.route('/api/movies', methods=['POST'])
def create_movie():
    data = request.json or {}
    
    # Extract data using the simple keys sent by the frontend JS
    title = data.get('title')
    year = data.get('year')
    duration = data.get('duration')
    rating = data.get('rating')
    plot = data.get('plot')
    industry_id = data.get('industry') # Expected to be an integer ID (1, 2, or 3)
    budget = data.get('budget')
    revenue = data.get('revenue')

    # Basic Validation
    if not all([title, year, industry_id]):
        return jsonify({'error': 'Title, Year, and Industry ID required'}), 400

    conn = get_connection()
    cursor = conn.cursor()
    
    try:
        # Start transaction for multi-table safety
        cursor.execute("START TRANSACTION;")

        # 1. INSERT INTO Movies (Core Table) - Using CORRECT column names
        movie_query = """INSERT INTO Movies (Title_English, Release_Year, Duration_Min, Plot_Summary, IMDB_Rating, Industry_ID)
                         VALUES (%s, %s, %s, %s, %s, %s)"""
        # Note: Values are passed as a tuple, ensuring correct data type handling by pymysql
        cursor.execute(movie_query, (title, year, duration, plot, rating, industry_id))
        new_id = cursor.lastrowid
        
        # 2. INSERT INTO Box_Office
        if budget or revenue:
            box_office_query = "INSERT INTO Box_Office (Movie_ID, Budget_INR_Cr, Revenue_INR_Cr) VALUES (%s, %s, %s)"
            cursor.execute(box_office_query, (new_id, budget, revenue))
        
        # 3. Commit transaction
        conn.commit()
        return jsonify({'success': True, 'Movie_ID': new_id}), 201

    except Exception as e:
        conn.rollback()
        # Foreign Key Error: (1452) is the common one we fixed
        return jsonify({'success': False, 'error': str(e)}), 500
        
    finally:
        cursor.close()
        conn.close()

# Delete movie (DELETE)
@app.route('/api/movies/<int:movie_id>', methods=['DELETE'])
def delete_movie(movie_id):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        query = "DELETE FROM Movies WHERE Movie_ID = %s"
        affected_rows = cursor.execute(query, (movie_id,))
        if affected_rows == 0:
            raise NotFound(f"Movie with ID {movie_id} not found.")
            
        conn.commit()
        return jsonify({'success': True})
    except NotFound as e:
        return jsonify({'error': str(e)}), 404
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        cursor.close()
        conn.close()


if __name__ == '__main__':
    app.run(port=3000, debug=True)